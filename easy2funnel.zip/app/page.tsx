"use client"
import Link from "next/link"
import { ArrowDown, Clock, Target, Mail, Instagram, Twitter } from "lucide-react"
import WaitlistForm from "@/components/waitlist-form"
import PricingCard from "@/components/pricing-card"
import TestimonialCard from "@/components/testimonial-card"
import UseCaseCard from "@/components/use-case-card"
import ValueCard from "@/components/value-card"

export default function Home() {
  const scrollToForm = () => {
    const formElement = document.getElementById("waitlist-form")
    if (formElement) {
      formElement.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="container mx-auto py-4 px-4 flex items-center justify-between">
        <Link href="/" className="text-xl font-bold">
          이지투 퍼널
        </Link>
        <nav className="hidden md:flex items-center space-x-6">
          <Link href="#" className="text-sm text-gray-600 hover:text-gray-900">
            홈
          </Link>
          <Link href="#features" className="text-sm text-gray-600 hover:text-gray-900">
            특징
          </Link>
          <Link href="#use-cases" className="text-sm text-gray-600 hover:text-gray-900">
            사용 사례
          </Link>
          <Link href="#automation" className="text-sm text-gray-600 hover:text-gray-900">
            자동화 퍼널
          </Link>
          <Link href="#" className="text-sm text-gray-600 hover:text-gray-900">
            랜딩페이지 생성기
          </Link>
          <Link href="#faq" className="text-sm text-gray-600 hover:text-gray-900">
            FAQ
          </Link>
        </nav>
        <div className="flex items-center space-x-4">
          <Link href="#" className="text-sm text-gray-600 hover:text-gray-900">
            로그인
          </Link>
          <Link
            href="#waitlist-form"
            className="bg-cyan-500 hover:bg-cyan-600 text-white px-4 py-2 rounded-full text-sm font-medium transition-colors"
          >
            무료 시작하기
          </Link>
        </div>
      </header>

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative py-20 bg-gradient-to-b from-sky-50 to-white">
          <div className="container mx-auto px-4 text-center">
            <div className="inline-block bg-sky-100 text-sky-800 px-4 py-1 rounded-full text-sm mb-6">
              소상공인과 지식창업자를 위한 마케팅 솔루션
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
              <span className="text-cyan-500">5분 만에</span> 나만의 퍼널 완성
            </h1>
            <h2 className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
              AI가 대신 설계해주는 랜딩페이지 & 마케팅 자동화 툴
            </h2>
            <button
              onClick={scrollToForm}
              className="bg-cyan-500 hover:bg-cyan-600 text-white px-6 py-3 rounded-full text-lg font-medium transition-colors flex items-center mx-auto"
            >
              얼리버드 안내받기
              <ArrowDown className="ml-2 h-4 w-4" />
            </button>

            <div className="mt-16 max-w-4xl mx-auto">
              <p className="text-lg text-gray-700 mb-6">
                랜딩페이지 제작부터 CRM까지 자동화해주는 완벽한 마케팅 퍼널 시스템. 5분 내에 전문가 수준의 마케팅을
                시작하세요.
              </p>
              <div className="flex flex-col md:flex-row justify-center gap-4 mt-8">
                <button className="bg-cyan-500 hover:bg-cyan-600 text-white px-6 py-3 rounded-full text-lg font-medium transition-colors">
                  무료로 시작하기
                </button>
                <button className="border border-gray-300 hover:border-gray-400 px-6 py-3 rounded-full text-lg font-medium transition-colors">
                  데모 살펴보기
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Key Value Section */}
        <section id="features" className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Easy2Funnel로 가능한 일들</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <ValueCard
                icon={<Clock className="h-10 w-10 text-cyan-500" />}
                title="⏱ 5분 안에 완성"
                description="입력만 하면 퍼널이 자동 생성돼요."
              />
              <ValueCard
                icon={<Target className="h-10 w-10 text-cyan-500" />}
                title="🎯 전환 중심 구조"
                description="고객 행동을 유도하는 카피와 디자인이 자동으로!"
              />
              <ValueCard
                icon={<Mail className="h-10 w-10 text-cyan-500" />}
                title="📩 자동 후속 액션"
                description="SMS/이메일 자동 연결로 리드 관리도 끝!"
              />
            </div>
          </div>
        </section>

        {/* Use Case Simulation */}
        <section id="use-cases" className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">이렇게 사용돼요</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <UseCaseCard
                title="1인 강사 김마케터"
                description="전자책 판매용 퍼널 자동 생성"
                imageSrc="/placeholder.svg?height=200&width=300"
              />
              <UseCaseCard
                title="디자인 없이 런칭하는 창업자"
                description="제품 상세페이지 자동 완성"
                imageSrc="/placeholder.svg?height=200&width=300"
              />
              <UseCaseCard
                title="마케팅 자동화 입문자"
                description="자동 발송 메시지까지 설정 완료"
                imageSrc="/placeholder.svg?height=200&width=300"
              />
            </div>
            <p className="text-sm text-gray-500 text-center mt-6">
              💡 유저가 클릭해도 작동하지 않음. 단순 데모용 UI입니다.
            </p>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">당신의 규모에 맞춰 골라보세요</h2>
            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <PricingCard
                title="Free"
                price="0원"
                features={["기본 퍼널 1개", "기본 템플릿 접근", "월 100명 방문자", "이메일 지원"]}
                isPopular={false}
              />
              <PricingCard
                title="Starter"
                price="29,000원"
                period="월"
                features={["퍼널 5개", "모든 템플릿 접근", "월 1,000명 방문자", "이메일/채팅 지원", "기본 자동화 기능"]}
                isPopular={true}
              />
              <PricingCard
                title="Pro"
                price="79,000원"
                period="월"
                features={[
                  "퍼널 무제한",
                  "커스텀 템플릿 제작",
                  "방문자 무제한",
                  "우선 지원",
                  "고급 자동화 기능",
                  "API 연동",
                ]}
                isPopular={false}
              />
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section id="testimonials" className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">후기 및 기대평</h2>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <TestimonialCard
                quote="디자인 없이도 이 정도 퀄리티라니… 놀랍네요!"
                author="@solobiz_maker"
                avatarSrc="/placeholder.svg?height=50&width=50"
              />
              <TestimonialCard
                quote="클릭 몇 번으로 이메일 마케팅까지 끝. 완전 혁명!"
                author="@booklaunch_101"
                avatarSrc="/placeholder.svg?height=50&width=50"
              />
            </div>
          </div>
        </section>

        {/* CTA & Waitlist Form */}
        <section id="waitlist-form" className="py-20 bg-gradient-to-b from-white to-sky-50">
          <div className="container mx-auto px-4 max-w-2xl">
            <h2 className="text-3xl font-bold text-center mb-6">정식 출시, 제일 먼저 알려드릴게요!</h2>
            <div className="text-center mb-8">
              <button className="bg-cyan-500 hover:bg-cyan-600 text-white px-6 py-3 rounded-full text-lg font-medium transition-colors">
                웨이팅 리스트 등록하기 🚀
              </button>
            </div>
            <WaitlistForm />
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Easy2Funnel</h3>
              <p className="text-gray-400">
                AI 기반 원클릭 마케팅 솔루션으로 랜딩페이지 제작부터 CRM까지 자동화해주는 완벽한 마케팅 퍼널
                시스템입니다.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">링크</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    홈
                  </Link>
                </li>
                <li>
                  <Link href="#features" className="text-gray-400 hover:text-white">
                    특징
                  </Link>
                </li>
                <li>
                  <Link href="#use-cases" className="text-gray-400 hover:text-white">
                    사용 사례
                  </Link>
                </li>
                <li>
                  <Link href="#pricing" className="text-gray-400 hover:text-white">
                    요금제
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">연락처</h3>
              <p className="text-gray-400 mb-4">문의사항이 있으시면 언제든지 연락주세요.</p>
              <Link href="mailto:contact@easy2funnel.com" className="text-cyan-400 hover:text-cyan-300">
                contact@easy2funnel.com
              </Link>
              <div className="flex space-x-4 mt-4">
                <Link href="#" className="text-gray-400 hover:text-white">
                  <Instagram className="h-6 w-6" />
                </Link>
                <Link href="#" className="text-gray-400 hover:text-white">
                  <Twitter className="h-6 w-6" />
                </Link>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500">
            <p>&copy; {new Date().getFullYear()} Easy2Funnel. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
